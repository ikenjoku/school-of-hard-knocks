require('babel-register')({
    presets: ['es2015-node6']
});

require('./server.js');