# school-of-hard-knocks
Base School Info System
